package br.com.leonardovieira.padroes.comportamentais.observer;

public interface Observer {

    void atualizar(String nomeProduto, int quantidade);
}
