package br.com.leonardovieira.padroesprojeto.comportamentais.strategy;

public class CarrinhoDeCompras {

    private PagamentoStrategy estrategiaDePagamento;

    public void setEstrategiaDePagamento(PagamentoStrategy estrategiaDePagamento) {
        this.estrategiaDePagamento = estrategiaDePagamento;
    }

    
    public void pagar(double valor) {
        estrategiaDePagamento.pagar(valor);
    }
}
