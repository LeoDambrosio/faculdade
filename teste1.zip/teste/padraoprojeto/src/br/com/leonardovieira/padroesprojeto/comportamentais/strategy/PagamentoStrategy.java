package br.com.leonardovieira.padroesprojeto.comportamentais.strategy;

public interface PagamentoStrategy {

    void pagar(double valor);
}
