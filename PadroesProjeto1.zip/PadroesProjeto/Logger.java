public class Logger {
    public void log(String message) {
        System.out.println("[LOG] " + message);
    }
}

