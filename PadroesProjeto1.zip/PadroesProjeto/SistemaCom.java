public class SistemaCom {

    public void executar() {
        Logger logger = Logger.getInstancia();
        logger.log("Iniciando o sistema...");
        logger.log("Processando dados...");
    }
}

