package br.com.leonardovieira.padroes.criacionais.exercicios.atv1;
 
public interface Caminhao {
    public void transportar();
}
