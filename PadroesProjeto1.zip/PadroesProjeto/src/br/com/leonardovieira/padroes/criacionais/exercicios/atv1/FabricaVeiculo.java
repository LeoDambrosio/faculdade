package br.com.leonardovieira.padroes.criacionais.exercicios.atv1;
 
public interface FabricaVeiculo {
    public Carro criarCarro();
    public Caminhao criarCaminhao();
}
