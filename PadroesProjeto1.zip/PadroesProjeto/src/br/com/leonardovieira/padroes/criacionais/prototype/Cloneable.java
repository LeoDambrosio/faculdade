package br.com.guilhermevillaca.padroes.criacionais.prototype;

/**
 *
 * @author villaca
 */
public interface Cloneable {
    
    Object clone();

}
