package br.com.leonardovieira.padroes.criacionais.abstractfactory;


public class CoelhoDePelucia implements Coelho{

    @Override
    public void exibir() {
        System.out.println("Coelho de Pelúcia");
    }


}
