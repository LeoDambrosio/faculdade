package br.com.leonardovieira.padroes.criacionais.exercicios.atv1;
 
public class CaminhaoCombustao implements Caminhao{

    @Override
    public void transportar() {
        System.out.println("Transportando no caminhao combustao");
    }

}
