package br.com.guilhermevillaca.padroes.criacionais.exercicios.atv2;

/**
 *
 * @author villaca
 */
public interface JogoTabuleiro {
    public void jogar();
}
