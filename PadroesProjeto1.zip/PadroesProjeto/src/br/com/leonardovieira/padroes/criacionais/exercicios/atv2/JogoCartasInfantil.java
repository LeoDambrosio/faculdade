package br.com.guilhermevillaca.padroes.criacionais.exercicios.atv2;

/**
 *
 * @author villaca
 */
public class JogoCartasInfantil implements JogoCartas {

    @Override
    public void embaralhar() {
        System.out.println("Jogando jogo cartas infantil");
    }

}
