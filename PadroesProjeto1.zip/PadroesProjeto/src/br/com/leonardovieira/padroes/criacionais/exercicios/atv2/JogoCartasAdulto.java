package br.com.guilhermevillaca.padroes.criacionais.exercicios.atv2;

/**
 *
 * @author villaca
 */
public class JogoCartasAdulto implements JogoCartas{

    @Override
    public void embaralhar() {
        System.out.println("Jogando jogo cartas adulto");
    }

}
