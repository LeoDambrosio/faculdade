package br.com.leonardovieira.padroes.criacionais.exercicios.atv1;
 
public class CarroEletrico implements Carro{

    @Override
    public void dirigir() {
        System.out.println("Dirigindo Carro Elétrico");
    }

}
