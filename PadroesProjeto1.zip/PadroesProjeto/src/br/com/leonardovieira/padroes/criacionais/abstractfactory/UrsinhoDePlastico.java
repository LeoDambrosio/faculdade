package br.com.leonardovieira.padroes.criacionais.abstractfactory;
 
public class UrsinhoDePlastico implements Ursinho {

    @Override
    public void exibir() {
        System.out.println("Ursinho de Plástico");
    }

}
