package br.com.leonardovieira.padroes.criacionais.abstractfactory;
 
public interface Ursinho {

    void exibir();

}
