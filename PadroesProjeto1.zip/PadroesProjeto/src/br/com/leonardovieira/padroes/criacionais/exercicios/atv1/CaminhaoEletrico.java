package br.com.leonardovieira.padroes.criacionais.exercicios.atv1;
 
public class CaminhaoEletrico implements Caminhao{

    @Override
    public void transportar() {
        System.out.println("Transportando no caminhao eletrico");
    }

}
