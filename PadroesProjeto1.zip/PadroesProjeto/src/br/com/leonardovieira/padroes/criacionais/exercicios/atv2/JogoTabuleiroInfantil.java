package br.com.guilhermevillaca.padroes.criacionais.exercicios.atv2;

/**
 *
 * @author villaca
 */
public class JogoTabuleiroInfantil implements JogoTabuleiro{

    @Override
    public void jogar() {
        System.out.println("Jogando jogo tabuleiro infantil");
    }

}
