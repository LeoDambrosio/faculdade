package br.com.leonardovieira.padroes.criacionais.abstractfactory;
 
public class UrsinhoDePelucia implements Ursinho{

    @Override
    public void exibir() {
        System.out.println("Ursinho de Pelúcia");
    }

}
