package br.com.guilhermevillaca.padroes.estruturais.proxy;

public interface ServicoBanco {

    void processarPagamento(String cliente, double valor);

}
