package br.com.guilhermevillaca.padroes.estruturais.adapter;

public interface Pagamento {
    void pagar(double valor);
}
