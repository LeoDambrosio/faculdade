package br.com.guilhermevillaca.padroes.estruturais.bridge;

/**
 *
 * @author villaca
 */
public class ControleRemotoBasico extends ControleRemoto {

    public ControleRemotoBasico(Dispositivo dispositivo) {
        super(dispositivo);
    }
}
