package br.com.leonardovieira.padroes.comportamentais.command;

public interface Pedido {

    void executar();

}
