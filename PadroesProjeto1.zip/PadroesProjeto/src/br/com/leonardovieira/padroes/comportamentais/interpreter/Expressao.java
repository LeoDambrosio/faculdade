package br.com.leonardovieira.padroes.comportamentais.interpreter;

public interface Expressao {

    int interpretar();

}
