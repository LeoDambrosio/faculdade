package br.com.leonardovieira.padroes.comportamentais.visitor_;

public interface Item {

    void aceitar(Visitante visitante);
}
