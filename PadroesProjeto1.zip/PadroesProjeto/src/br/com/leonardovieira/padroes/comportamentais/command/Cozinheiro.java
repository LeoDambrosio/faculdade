package br.com.leonardovieira.padroes.comportamentais.command;

public class Cozinheiro {
    
    public void fazerPizza() {
        System.out.println("Cozinheiro: Fazendo uma pizza...");
    }

    public void fazerHamburguer() {
        System.out.println("Cozinheiro: Fazendo um hambúrguer...");
    }
}
