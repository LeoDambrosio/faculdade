package br.com.guilhermevillaca.padroes.exercicios.estrutural1;

/**
 *
 * @author guilherme.villaca
 */
public interface Notificacao {

    String enviar(String mensagem);
}
