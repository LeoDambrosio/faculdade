package br.com.guilhermevillaca.padroes.exercicios.comportamental2;

/**
 *
 * @author guilherme.villaca
 */
public interface EstrategiaDesconto {
    double calcularDesconto(double valor);
}
