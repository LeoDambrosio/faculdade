package br.com.guilhermevillaca.padroes.exercicios.comportamental1;

/**
 *
 * @author guilherme.villaca
 */
public interface Observer {

    void atualizar(String noticia);
}
