package br.com.guilhermevillaca.padroes.exercicios.estrutural2;

/**
 *
 * @author guilherme.villaca
 */
public class Notificacoes {

    public void enviarNotificacao(String nomeUsuario, String mensagem) {
        System.out.println("Notificação para '" + nomeUsuario + "': " + mensagem);
    }
}
