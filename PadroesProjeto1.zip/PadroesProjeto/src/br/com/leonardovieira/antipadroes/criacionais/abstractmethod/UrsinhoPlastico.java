package br.com.guilhermevillaca.antipadroes.criacionais.abstractmethod;
class UrsinhoPlastico {
    public void exibir() {
        System.out.println("Ursinho de Plástico criado!");
    }
}