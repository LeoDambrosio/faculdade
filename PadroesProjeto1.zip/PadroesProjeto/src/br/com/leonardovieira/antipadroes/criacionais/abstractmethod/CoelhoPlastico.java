package br.com.guilhermevillaca.antipadroes.criacionais.abstractmethod;
class CoelhoPlastico {
    public void exibir() {
        System.out.println("Coelho de Plástico criado!");
    }
}