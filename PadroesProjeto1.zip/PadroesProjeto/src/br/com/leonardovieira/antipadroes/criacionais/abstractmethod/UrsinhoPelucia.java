package br.com.guilhermevillaca.antipadroes.criacionais.abstractmethod;
class UrsinhoPelucia {
    public void exibir() {
        System.out.println("Ursinho de Pelúcia criado!");
    }
}