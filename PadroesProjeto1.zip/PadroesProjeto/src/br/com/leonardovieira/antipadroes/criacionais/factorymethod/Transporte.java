package br.com.guilhermevillaca.antipadroes.criacionais.factorymethod;

public class Transporte {
    public void entregar() {
        System.out.println("Entrega sendo feita.");
    }
}
