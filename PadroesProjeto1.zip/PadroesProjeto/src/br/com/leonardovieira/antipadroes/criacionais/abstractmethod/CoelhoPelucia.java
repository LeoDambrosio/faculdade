package br.com.guilhermevillaca.antipadroes.criacionais.abstractmethod;
// Classes dos brinquedos
class CoelhoPelucia {
    public void exibir() {
        System.out.println("Coelho de Pelúcia criado!");
    }
}