package br.com.guilhermevillaca.antipadroes.estruturais.decorator;

// ☕ Café básico
public class Cafe {
    public double getPreco() {
        return 5.00;
    }

    public String getDescricao() {
        return "Café simples";
    }
}