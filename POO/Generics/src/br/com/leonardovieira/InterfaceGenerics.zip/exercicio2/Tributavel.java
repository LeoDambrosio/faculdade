public interface Tributavel {
    double calcularTributos();
}

