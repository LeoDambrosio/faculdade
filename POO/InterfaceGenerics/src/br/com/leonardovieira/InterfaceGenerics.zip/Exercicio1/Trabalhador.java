public interface Trabalhador {
    void trabalhar();
    void descansar();
}
