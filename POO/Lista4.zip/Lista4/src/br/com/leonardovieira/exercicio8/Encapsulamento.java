package Lista4.src.br.com.leonardovieira.exercicio8;

public class Encapsulamento {

}
//Qual princípio da POO garante que os atributos de uma classe só podem ser acessados por meio de métodos específicos?
//A) Polimorfismo
//B) Herança
//C) Encapsulamento
//D) Abstração

// Resposta Correta letra C.