package Lista4.src.br.com.leonardovieira.exercicio9;

public class PalavraChaveThis {

}
//O que a palavra-chave this faz em um método de instância?
//A) Cria uma nova instância da classe.
//B) Se refere ao próprio objeto da classe.
//C) Declara um atributo estático.
//D) Chama o construtor da superclasse.

// Resposta Correta letra B. 