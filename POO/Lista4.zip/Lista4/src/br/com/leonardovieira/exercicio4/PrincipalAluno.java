package Lista4.src.br.com.leonardovieira.exercicio4;

public class PrincipalAluno {
    public static void main(String[] args) {
        Aluno aluno1 = new Aluno("Leonardo Vieira", 8.5);
        Aluno aluno2 = new Aluno("Ana Souza", 9.2);

        aluno1.exibirInfo();
        aluno2.exibirInfo();
    }
}
