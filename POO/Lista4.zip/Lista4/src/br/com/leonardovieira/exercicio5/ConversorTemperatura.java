package Lista4.src.br.com.leonardovieira.exercicio5;

public class ConversorTemperatura {

    public static double celsiusParaFahrenheit(double celsius) {
        return (celsius * 9 / 5) + 32;
    }
}

