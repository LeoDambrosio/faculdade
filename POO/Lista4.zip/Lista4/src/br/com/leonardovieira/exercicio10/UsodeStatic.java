package Lista4.src.br.com.leonardovieira.exercicio10;

public class UsodeStatic {

}
//O que acontece se um método for declarado como static?
//A) Ele pode ser chamado sem instanciar a classe.
//B) Ele só pode ser acessado por instâncias da classe.
//C) Ele pode acessar atributos de instância livremente.
//D) Ele não pode acessar atributos da classe.

// Resposta Correta letra A.
