package Lista3.src.br.com.leonardovieira.exercicio1;

public class Carro {
    String marca;
    String modelo;
    int ano;

    public void exibirInformacoes() {
        System.out.println("Marca: " + marca);
        System.out.println("Modelo: " + modelo);
        System.out.println("Ano: " + ano);
    }
}


