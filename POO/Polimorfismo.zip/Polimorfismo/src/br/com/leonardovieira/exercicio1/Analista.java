package br.com.leonardovieira.exercicio1;

public class Analista extends Funcionario {

    public Analista(String nome, double salarioBase) {
        super(nome, salarioBase);
    }

    // Usa o método herdado
}