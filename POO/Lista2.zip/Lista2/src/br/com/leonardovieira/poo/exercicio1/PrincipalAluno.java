package br.com.leonardovieira.poo.exercicio1;

public class PrincipalAluno {
    public static void main(String[] args) {
        Aluno aluno = new Aluno("Leonardo Vieira Dambrosio", 21, "123456");

        aluno.exibirInformacoes();
    }
}
