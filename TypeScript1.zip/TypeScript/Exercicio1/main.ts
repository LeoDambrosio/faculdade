import {Exercicio1 } from "./Exercicio1";

const exercicio1 = new Exercicio1("Leonardo", 21, true, [7, 8, 9, 7, 9]);
exercicio1.mostrarDados();