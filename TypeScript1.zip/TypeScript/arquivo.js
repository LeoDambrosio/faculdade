function greet(name) {
    return "Ol\u00E1, ".concat(name, "! Bem-vindo ao TypeScript.");
}
console.log(greet("Aluno"));
