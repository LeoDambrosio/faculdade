function greet(name: string): string {
return `Olá, ${name}! Bem-vindo ao TypeScript.`;
}
console.log(greet("Aluno"));
